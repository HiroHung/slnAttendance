﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace prjAttendance.Models
{
    public enum ContactRsult
    {
        成功聯繫=0,
        無法聯繫=1
    }

    public enum WeekType
    {
        星期一=1,
        星期二=2,
        星期三=3,
        星期四=4,
        星期五=5
    }

    public enum LessonOrderType
    {
        早自修=0,
        午休=9,
        第一堂=1,
        第二堂=2,
        第三堂=3,
        第四堂=4,
        第五堂=5,
        第六堂=6,
        第七堂=7,
        第八堂=8
    }

    public enum AttendanceType
    {
    出席=0,
    遲到=1,
    事假=2,
    病假=3,
    喪假=4,
    曠課=5
    }

    public enum GenderType
    {
        男=0,
        女=1
    }
}