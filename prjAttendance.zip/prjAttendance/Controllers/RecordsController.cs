﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using prjAttendance.Models;
using prjAttendance.Security;

namespace prjAttendance.Controllers
{
    public class RecordsController : ApiController
    {
        private Model db = new Model();
        // GET: api/Records
        public IQueryable<Record> GetRecords()
        {
            return db.Records;
        }

        // GET: api/Records/5
        [ResponseType(typeof(Record))]
        public IHttpActionResult GetRecord(int LessonOrder, int ClassId)
        {
            var record = db.Records.Where(x => x.LessonDate == DateTime.Today && (int)x.LessonOrder == LessonOrder && x.ClassId == ClassId).ToList();

            if (record.Count == 0)
            {
                var result = db.Students.Where(x => x.ClasssId == ClassId).Select(x => new
                {
                    id = x.Id,
                    學號 = x.StudentId,
                    姓名 = x.Name
                });
                return Ok(new
                {
                    method = "post",
                    date = result
                });
            }
            else
            {
                var result = db.Students.Where(x => x.ClasssId == ClassId).Select(x => new
                {
                    id = x.Id,
                    學號 = x.StudentId,
                    姓名 = x.Name,
                    出席狀態 = x.Records.Where(y => y.LessonDate == DateTime.Today && (int)y.LessonOrder == LessonOrder).Select(y => new
                    {
                        狀態 = y.Attendance.ToString()
                    })
                });
                return Ok(new
                {
                    method = "get",
                    date = result
                });
            }
        }

        // PUT: api/Records/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRecord(int id, Record record)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != record.Id)
            {
                return BadRequest();
            }

            db.Entry(record).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RecordExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Records
        [ResponseType(typeof(Record))]
        //public IHttpActionResult PostRecord(int LessonOrder, int Attendance, int StudentID, int ClassId)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }
        //    var recordlList = db.Records.Where(x => x.LessonDate == DateTime.Today && (int)x.LessonOrder == LessonOrder && x.ClassId == ClassId).ToList();
        //    string Token = Request.Headers.Authorization.Parameter;

        //    if (recordlList.Count == 0)
        //    {
        //        Record record = new Record();
        //        record.RollCallTime = DateTime.Now;
        //        record.LessonDate = DateTime.Today;
        //        record.LessonOrder = (LessonOrderType)LessonOrder;
        //        record.Attendance = (AttendanceType)Attendance;
        //        record.StudentId = StudentID;
        //        record.RollCallTeacherId = JwtAuthUtil.GetId(Token);
        //        record.ClassId = ClassId;
        //        record.Week = (WeekType)Utility.GetWeek();
        //        db.Records.Add(record);
        //        db.SaveChanges();
        //        return CreatedAtRoute("DefaultApi", new { id = record.Id }, record);
        //    }
        //    else
        //    {
        //        //List<Record> record = db.Records
        //        //    .Where(x => x.LessonDate == DateTime.Today && (int)x.LessonOrder == LessonOrder &&
        //        //                x.ClassId == ClassId).ToList();
        //        //record.RollCallTime = DateTime.Now;
        //        //record.LessonDate = DateTime.Today;
        //        //record.LessonOrder = (LessonOrderType)LessonOrder;
        //        //record.Attendance = (AttendanceType)Attendance;
        //        //record.StudentId = StudentID;
        //        //record.RollCallTeacherId = JwtAuthUtil.GetId(Token);
        //        //record.ClassId = ClassId;
        //        //record.Week = (WeekType)Utility.GetWeek();
        //        //db.Entry(record).State = EntityState.Modified;
        //        //db.SaveChanges();
        //        //return StatusCode(HttpStatusCode.NoContent);
        //    }
        //}

        // DELETE: api/Records/5
        [ResponseType(typeof(Record))]
        public IHttpActionResult DeleteRecord(int id)
        {
            Record record = db.Records.Find(id);
            if (record == null)
            {
                return NotFound();
            }

            db.Records.Remove(record);
            db.SaveChanges();

            return Ok(record);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RecordExists(int id)
        {
            return db.Records.Count(e => e.Id == id) > 0;
        }
    }
}